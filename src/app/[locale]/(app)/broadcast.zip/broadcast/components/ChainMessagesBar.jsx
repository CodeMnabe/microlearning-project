import { Copy, MessageSquarePlus, Plus, Trash2, X } from "lucide-react";

import styles from "../broadcast.module.css";

export default function ChainMessagesBar({
  enabled,
  chainMode,
  setChainMode,
  chainSteps,
  activeChainStepIndex,
  setActiveChainStepIndex,
  addChainStep,
  duplicateChainStep,
  removeChainStep,
  hasFallbackTemplate,
}) {
  if (!enabled && !chainMode) {
    return null;
  }

  return (
    <div className={styles.chainBox}>
      <div className={styles.chainHeader}>
        <div className={styles.chainTitleWrap}>
          <div className={styles.chainTitle}>
            <MessageSquarePlus size={17} />
            <span>Read chain messages</span>
          </div>

          <div className={styles.chainHelp}>
            Write freeform messages for the chain. Select a WhatsApp template as
            the fallback if the 24h window is closed.
          </div>
        </div>

        <button
          type="button"
          className={`${styles.secondaryActionBtn} ${
            chainMode ? styles.chainExitBtn : ""
          }`}
          onClick={() => setChainMode((value) => !value)}
        >
          {chainMode ? (
            <>
              <X size={15} />
              <span>Exit chain</span>
            </>
          ) : (
            <>
              <MessageSquarePlus size={15} />
              <span>Create chain</span>
            </>
          )}
        </button>
      </div>

      {!enabled && chainMode && (
        <div className={styles.chainWarning}>
          Read chains are disabled in Automations. Enable the feature before
          sending.
        </div>
      )}

      {enabled && chainMode && !hasFallbackTemplate && (
        <div className={styles.chainWarning}>
          Select a WhatsApp template. It will be used only when the contact's
          24h window is closed.
        </div>
      )}

      {chainMode && (
        <>
          <div className={styles.chainStepTabs}>
            {chainSteps.map((step, index) => (
              <button
                key={step.id}
                type="button"
                className={`${styles.chainStepTab} ${
                  activeChainStepIndex === index
                    ? styles.chainStepTabActive
                    : ""
                }`}
                onClick={() => setActiveChainStepIndex(index)}
              >
                Message {index + 1}
              </button>
            ))}

            <button
              type="button"
              className={styles.chainStepAdd}
              onClick={addChainStep}
              disabled={chainSteps.length >= 10}
              title={
                chainSteps.length >= 10
                  ? "Maximum of 10 messages"
                  : "Add message"
              }
            >
              <Plus size={15} />
            </button>
          </div>

          <div className={styles.chainActionsRow}>
            <button
              type="button"
              className={styles.kbdBtn}
              onClick={duplicateChainStep}
              disabled={chainSteps.length >= 10}
            >
              <Copy size={14} />
              <span>Duplicate current</span>
            </button>

            <button
              type="button"
              className={styles.kbdBtn}
              onClick={() => removeChainStep(activeChainStepIndex)}
              disabled={chainSteps.length <= 2}
            >
              <Trash2 size={14} />
              <span>Remove current</span>
            </button>

            <span className={styles.chainCounter}>
              {chainSteps.length}/10 messages
            </span>
          </div>
        </>
      )}
    </div>
  );
}
